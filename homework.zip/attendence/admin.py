from django.contrib import admin
from attendence.models import Attendence

admin.site.register(Attendence)

# Register your models here.
